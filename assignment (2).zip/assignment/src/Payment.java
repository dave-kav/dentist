/**
 * Payment class, stores details of a payment that a patient made on a particular date.
 * 
 * @author (Dave Kavanagh) 
 * @version (1.0)
 */
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
public class Payment
{
	// instance variables
	private static int paymentNo=0;
	private int myPaymentNo;
	private double payment;
	private String paymentDate;
	private SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-mm-yyyy");
	private Date myDate;

	public Payment()
	{
		paymentNo++;
		myPaymentNo=paymentNo;
	}

	public Payment(String paymentDate, double payment) throws ParseException
	{
		paymentNo++;
		myPaymentNo=paymentNo;
		this.paymentDate=paymentDate;
		this.payment=payment;
		myDate = dateFormatter.parse(paymentDate);
	}

	public void setPayment(double payment)
	{
		this.payment=payment;
	}

	public void setPaymentDate(String paymentDate) throws ParseException
	{
		this.myDate = dateFormatter.parse(paymentDate);
	}

	public int getMyPaymentNo()
	{
		return this.myPaymentNo;
	}

	public double getPayment()
	{
		return this.payment;
	}

	public Date getPaymentDate()
	{
		return this.myDate;
	}

	public String toString()
	{
		return ("\n" + this.myPaymentNo + "\t" + this.payment + "\t" + this.paymentDate);
	}

	public void print()
	{
		System.out.println(toString());
	}
}
