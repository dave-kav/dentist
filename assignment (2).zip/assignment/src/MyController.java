/**
 * Dave Kavanagh
 * R00013469
 */
import java.awt.HeadlessException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class MyController {
	
	//main collection of procedures and patients
	ArrayList<Patient> patientList = new ArrayList<Patient>();
	ArrayList<Procedure> procedureList = new ArrayList<Procedure>();

	public MyController() {	}

	public static void main (String [] args) {
		new createGUI();		
	}

	//adds a patient object to the ArrayList
	public boolean addPatient(String name, String address, String phoneNumber) {
		if (name.isEmpty() || address.isEmpty() || phoneNumber.isEmpty())		//display an error message if a field is not populated
		{
			JOptionPane.showMessageDialog(null, "Please enter values for all fields.");
		}
		else
		{
			Patient myPatient=new Patient(name, address, phoneNumber);
			if (patientList.add(myPatient))
			{
				JOptionPane.showMessageDialog(null, "New patient record added for " + name + ".\nPatient number: " + myPatient.getMyPatientNo());
				return true;
			}
		}
		return false;
	}

	//calls one of two methods of this class to search for a Patient, either by name or patient number
	public Patient searchPatient(String patName, int patNo) {
		int index;
		if ((nameSearch(patientList, patName) >-1)) 	//search by name will return an index greater than -1 if a patient is found
			index = nameSearch(patientList, patName);
		else
			index = search(patientList, patNo);			//search uses patient number, will return an index greater than -1 if a patient is found
		if (index >-1)
			return patientList.get(index);				//return the Patient object found
		else return null;
	}

	//returns a String containing all patient details,  including each patients own procedures and payments
	public String viewAllPatients() {
		if (patientList.size()<1)	//if no patients yet exist, display message
		{
			JOptionPane.showMessageDialog(null, "No records to display");
			return null;
		}
		
		int count=0;
		String temp ="Pat. Number\tName\tAddress\tPhone\n======\t======\t======\t======";
		
		while(count<patientList.size())
		{
			temp += (patientList.get(count).toString() + "\n");	
			temp += amountOwed(patientList.get(count));
			count++;
		}
		return temp;
	}

	
	public boolean updatePatient(Patient myPatient, String name, String address, String phone) {
		if (name.isEmpty() && address.isEmpty() && phone.isEmpty())			//if no values are entered in GUI, display a message
		{
			JOptionPane.showMessageDialog(null, "No values entered");
			return false;
		}
		//if any one or more of the following are populated there will be an update to the patient record
		if (!name.isEmpty())
			myPatient.setPatientName(name);
		if (!address.isEmpty())
			myPatient.setPatientAdd(address);
		if (!phone.isEmpty())
			myPatient.setPatientPhone(phone);
		JOptionPane.showMessageDialog(null, "Paitent record updated.");
		return true;
	}

	//removes a patient record from the system
	public boolean deletePatient(Patient myPatient) {
		for (int i=0;i<patientList.size();i++)
		{
			if (patientList.get(i).getMyPatientNo()==myPatient.getMyPatientNo())
			{
				patientList.remove(i);
				JOptionPane.showMessageDialog(null, "Patient record removed");
				return true;
			}
		}
		JOptionPane.showMessageDialog(null, "Record not found");
		return false;
	}

	//adds a procedure to the main system collection
	public boolean addProcedure(String procName, String procCost) {
		if (procName.isEmpty() || procCost.isEmpty())		//if a value is not entered, display error
			JOptionPane.showMessageDialog(null, "Please enter all values.");
		else
		{
			Double tempProcCost	= Double.parseDouble(procCost);

			Procedure myProcedure = new Procedure(procName, tempProcCost);
			if (procedureList.add(myProcedure))
			{
				JOptionPane.showMessageDialog(null, "New procedure record added for " + procName);
				return true;
			}
		}
		return false;
	}

	//finds a and returns given Procedure so that actions can be performed on it, uses one of two methods of this class to search by name or procedure number
	public Procedure searchProcedure(String procName, String procNoString)	{
		int index = -1;
		int tempProcNo = 0;
		if (!procNoString.isEmpty())
			tempProcNo = Integer.parseInt(procNoString);
		if ((procNameSearch(procedureList, procName) >-1)) 
			index = procNameSearch(procedureList, procName);		//uses the procNameSearch function to find the Procedure by name
		else
			index = procSearch(procedureList, tempProcNo);			//finds the procedure by procedure number
		if (index >-1)
			return procedureList.get(index);
		else return null;
	}

	//returns String representation of all of the systems collection of procedures
	public String viewAllProcedures() {
		if (procedureList.size()<1)		//if none yet exist, display an error
		{
			JOptionPane.showMessageDialog(null, "No records to display");
			return null;
		}
		
		int count=0;
		String temp ="Number\tName\tCost\n======\t======\t======\t";
		
		while(count<procedureList.size())
		{
			temp += (procedureList.get(count).toString() + "\n");	
			count++;
		}
		return temp;
	}
	
	//similar to method above but works around bug on patient search where error dialog always shows if no procedures yet exist
	public String listAllProcedures () {
		if (procedureList.size()<1)
			return null;
		
		int count=0;
		
		String temp ="Number\tName\tCost\n======\t======\t======\t";
		while(count<procedureList.size())
		{
			temp += (procedureList.get(count).toString() + "\n");	
			count++;
		}
		return temp;
	}

	//passes parameters to relevant setters of a Procedure object to update
	public boolean updateProcedure (Procedure myProcedure, String procName, String procCostString) {
		if (procName.isEmpty()&&procCostString.isEmpty())			//display error if no details entered 
		{
			JOptionPane.showMessageDialog(null, "No details entered");
			return false;
		}
		//if any detail is provided, update accordingly 
		if (!procName.isEmpty())
			myProcedure.setProcedureName(procName);
		if (!procCostString.isEmpty())
		{
			Double tempProcCost	= Double.parseDouble(procCostString);
			myProcedure.setCost(tempProcCost);
		}
		JOptionPane.showMessageDialog(null, "Procedure details updated");
		return true;
	}

	//removes a procedure from the system collections
	public boolean deleteProcedure(Procedure myProcedure) {
		for (int i=0;i<procedureList.size();i++)
		{
			if (procedureList.get(i).getMyProcNo()==myProcedure.getMyProcNo())
			{
				procedureList.remove(i);
				JOptionPane.showMessageDialog(null, "Procedure removed");
				return true;
			}
		}
		JOptionPane.showMessageDialog(null, "Procedure not found");
		return false;
	}

	//adds a procedure to a patients individual collection
	public boolean addPatientProc(Patient myPatient, int index) {
//		redundant code from earlier design
//		if (procedureList.size()<1)
//		{
//			JOptionPane.showMessageDialog(null, "No procedures to add");
//			return false;
//		}
		Procedure myProcedure = procedureList.get(index);
		if (myPatient.addProcedure(myProcedure))
		{
			JOptionPane.showMessageDialog(null, "Procedure added to patient's record");
			return true;
		}
		JOptionPane.showMessageDialog(null, "An error occurred");
		return false;
	}
	
	//as above but removes a procedure from a patients own collection
	public boolean removePatientProc(Patient myPatient, int index) {
//		redundant code from earlier design
//		if (myPatient.getP_procList().size()<1)
//		{
//			JOptionPane.showMessageDialog(null, "No procedures to remove");
//			return false;
//		}
		if (myPatient.removeProcedure(index))
		{
			JOptionPane.showMessageDialog(null, "Procedure removed from patient records");
			return true;
		}
		JOptionPane.showMessageDialog(null, "An error occurred");
		return false;
	}
	
	//returns names of system collection of procedures
	public String getProcedureNames()
	{
		String names = "";
		for (int i=0;i<procedureList.size();i++)
		{
			names += procedureList.get(i).getProcName() + ";";
		}
		return (names);
	}
	
	//as above but returns names of an individual patients collection of procedures
	public String getPatientProcedureNames(Patient myPatient) {
		String names = "";
		for (int i=0;i<myPatient.getP_procList().size();i++)
		{
			names += myPatient.getP_procList().get(i).getProcName() + ";";
		}
		return (names);
	}

	//adds a payment to a patients collection
	public boolean addPatientPayment(Patient myPatient, String date, String amount) throws HeadlessException, ParseException {
		double payAmount = Double.parseDouble(amount);
		if (myPatient.addPayment(date, payAmount))
		{
			JOptionPane.showMessageDialog(null, "Payment added to patient's record");
			return true;
		}
		JOptionPane.showMessageDialog(null, "An error occurred");
		return false;
	}

	//the following method is used in tab three of the GUI, searches if a patient exists and adds a payment if successful
	public boolean searchAddPayment(String name, String date, String amount) throws HeadlessException, ParseException {
		if (patientList.size()<1)
		{
			JOptionPane.showMessageDialog(null, "Patient record not found");
			return false;
		}
		
		if(name.isEmpty() || (date.isEmpty() || amount.isEmpty()))
		{
			JOptionPane.showMessageDialog(null, "Please provide all details");
			return false;
		}
		
		else
		{
			int index=-1;
			
			if ((nameSearch(patientList, name) >-1)) 	//search by name will return an index greater than -1 if a patient is found
				index = nameSearch(patientList, name);

			double payAmount = Double.parseDouble(amount);
			
			if(patientList.get(index).addPayment(date, payAmount))
			{
				JOptionPane.showMessageDialog(null, "Payment added to patient's record");
				return true;
			}
		}
		JOptionPane.showMessageDialog(null, "Patient record not found");
		return false;
	}

	//backs up info to files on system exit
	public void backup() throws IOException {
		//create file and writers for patient info
		File procedureFile = new File("procedures.txt");
		if (!procedureFile.exists())
			procedureFile.createNewFile();
		FileWriter procfw = new FileWriter(procedureFile);
		BufferedWriter procbw = new BufferedWriter(procfw);

		//create file and writers for procedure info
		File patientsFile = new File("patients.txt");
		if (!patientsFile.exists())
			patientsFile.createNewFile();
		FileWriter patfw = new FileWriter(procedureFile);
		BufferedWriter patbw = new BufferedWriter(patfw);

		for (int i=0;i<procedureList.size();i++)
		{
			procbw.write(procedureList.get(i).getMyProcNo());
			procbw.write(procedureList.get(i).getProcName());
			procbw.write((int) procedureList.get(i).getProcCost());
		}
		procbw.close();

		for (int i=0;i<patientList.size();i++)
		{
			patbw.write(patientList.get(i).getMyPatientNo());
			patbw.write(patientList.get(i).getPatientName());
			patbw.write(patientList.get(i).getPatientAdd());
			patbw.write(patientList.get(i).getPatientPhone());

			for (int j=0;j<patientList.get(i).getP_paymentList().size();j++)
			{
				patbw.write(patientList.get(i).getP_paymentList().get(j).getMyPaymentNo());
				patbw.write((int) patientList.get(i).getP_paymentList().get(j).getPayment());
				patbw.write(patientList.get(i).getP_paymentList().get(j).getPaymentDate().toString());
			}

			for (int k=0;k<patientList.get(i).getP_procList().size();k++)
			{
				patbw.write(patientList.get(i).getP_procList().get(k).getMyProcNo());
				patbw.write(patientList.get(i).getP_procList().get(k).getProcName());
				patbw.write((int) patientList.get(i).getP_procList().get(k).getProcCost());
			}

			patbw.close();
		}
	}

	//find out if patient owes money by generating running totals of all a payments procedures and payments and calculating the difference
	public double calcIsPaid(Patient myPatient)
	{
		double procCostTotal=0;
		double payTotal=0;

		//get total cost of procedures 
		for (int i=0;i<myPatient.getP_paymentList().size();i++)
		{
			payTotal += myPatient.getP_paymentList().get(i).getPayment();
		}

		//get total of payments
		for (int i=0;i<myPatient.getP_procList().size();i++)
		{
			procCostTotal += myPatient.getP_procList().get(i).getProcCost();
		}

		//return amount overpaid
		if (procCostTotal < payTotal)
		{
			myPatient.setIsPaid(true);
			return Math.round((procCostTotal-payTotal) * 100.0) / 100.0;
		}

		//return amount owed
		else if (procCostTotal > payTotal)
		{
			myPatient.setIsPaid(false);
			return Math.round((procCostTotal-payTotal) * 100.0) / 100.0;
		}
		
		else 
			myPatient.setIsPaid(true);
		
		return 0;
	}
	
	//returns a String representation of amount owed by patient
	public String amountOwed(Patient myPatient) {
		String owed="";
		if (calcIsPaid(myPatient)>0)			//calcIsPaid works out whether a patient owes money
		{
			owed += ("Amount owed: " + (calcIsPaid(myPatient)) + "\n==============================================");
		}
		else if ((calcIsPaid(myPatient)<0))
		{
			owed += ("Account in credit: " + (calcIsPaid(myPatient)) + "\n==============================================");
		}
		else
			owed += ("No money owed\n==============================================");
		return owed;
	}

	//methods used in searching patients and procedures below here
	//search for a patient by patient number
	public int search(ArrayList<Patient> patientList, int patNo)
	{
		int count=0; //used to track values in array
		while(count<patientList.size())
		{
			if (patientList.get(count).getMyPatientNo()==(patNo))
				return count;
			else count++;
		}
		return -1;
	}

	//search fora  patient by name
	public int nameSearch(ArrayList<Patient> patientList, String patName)
	{
		int count=0; //used to track values in array
		while(count<patientList.size())
		{
			if (patientList.get(count).getPatientName().equalsIgnoreCase(patName))
				return count;
			else count++;
		}
		return -1;
	}

	//search for a procedure by number
	public int procSearch(ArrayList<Procedure> procList, int procSearch)
	{
		int count=0; //used to track values in array
		while(count<procList.size())
		{
			if (procList.get(count).getMyProcNo()==(procSearch))
				return count;
			else count++;
		}
		return -1;
	}

	public int procNameSearch(ArrayList<Procedure> procList, String procNameSearch)
	{
		int count=0; //used to track values in array
		while(count<procList.size())
		{
			if (procList.get(count).getProcName().equalsIgnoreCase(procNameSearch))
				return count;
			else count++;
		}
		return -1;
	}
}