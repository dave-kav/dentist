/**
 * Dave Kavanagh
 * R00013469
 */
import javax.swing.*;
import javax.swing.plaf.ColorUIResource;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.text.ParseException;

public class createGUI extends JFrame {

	private static JFrame frame, popupFrame, procPopupFrame;
	private static JTabbedPane tp, patientTP, procedureTP, paymentTP;
	public static MyController controller = new MyController();

	public createGUI () {
		this.createMainDisplay();
	}

	//creates basic frame, calls methods to create inner panels and components
	private void createMainDisplay() {

		JFrame.setDefaultLookAndFeelDecorated(true);							//gives alternative theme to panel visuals
		frame 				= 	new JFrame 	("Dentist Administration System");
		frame.setDefaultCloseOperation		(JFrame.DO_NOTHING_ON_CLOSE);		//prevents system exiting when x is clicked
		frame.addWindowListener(new WindowAdapter() {							//this line and following inner class implements save option when x clicked
			public void windowClosing (WindowEvent event) {
				int result1, result2;
				result1 = JOptionPane.showConfirmDialog(null, "Are you sure you wish to exit?", null, JOptionPane.YES_NO_OPTION);
				if (result1 == JOptionPane.YES_OPTION)
				{
					result2 = JOptionPane.showConfirmDialog(null, "Would you like to backup your data first?", null, JOptionPane.YES_NO_OPTION);
					if (result2 == JOptionPane.YES_OPTION)
					{
						try {
							controller.backup();
							System.exit(0);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					else 
						System.exit(0);
				}
			}
		});
		frame.setSize					(390,400);
		
		tp 					= 	new JTabbedPane();
		//creates tabs
		patientTP 			= 	new JTabbedPane();
		procedureTP 		=  	new JTabbedPane();
		paymentTP 			= 	new JTabbedPane();
		tp.addTab				("Patient", patientTP);
		tp.addTab				("Procedures", procedureTP);
		tp.addTab				("Payments", paymentTP);
		//methods which construct tab contents
		createTabOne();
		createTabTwo();
		createTabThree();		
		//finalise
		frame.getContentPane	().add	(tp); 
		frame.isAlwaysOnTop				();
		frame.setResizable				(false);
		frame.setLocationRelativeTo		(null);
		frame.setVisible				(true);

	}

	private void createTabOne()
	{		
		//set layout of first tab
		patientTP.setLayout		(new BoxLayout(patientTP, BoxLayout.Y_AXIS));
		//create panels for 1st tab
		JPanel patMain 		= 	 new JPanel();
		patientTP.add			(patMain);
		patMain.setLayout		(new BoxLayout(patMain, BoxLayout.Y_AXIS));
		//create inner panels
		JPanel patTop		=	new JPanel();
		patTop.setLayout		(new BorderLayout());
		patTop.setMaximumSize	(new Dimension(390,150));
		JPanel patMiddle	=	new JPanel();
		patMiddle.setLayout		(new BorderLayout());
		patMiddle.setMaximumSize(new Dimension(390,150));
		JPanel patBottom	=	new JPanel();
		patBottom.setLayout		(new BorderLayout());
		//add inner panels to main panel
		patMain.add				(patTop);
		patMain.add				(patMiddle);
		patMain.add				(patBottom);	
		//method calls to create contents of panels for tab one
		tabOneTop(patTop);
		tabOneMiddle(patMiddle);
		tabOneBottom(patBottom);		
	}

	private void tabOneTop(JPanel panel) {
		//create top components for 1st tab
		JLabel nameL 		= 	new JLabel("Patient Name:");
		JLabel addressL		= 	new JLabel("Address:");
		JLabel phoneL 		= 	new JLabel("Phone Number:");
		JTextField name 	= 	new JTextField(24);
		JTextField address	= 	new JTextField(24);
		JTextField phone 	= 	new JTextField(24);
		JButton add			= 	new JButton("Submit");
		JButton reset		= 	new JButton("Reset");
		JPanel topLeft 		=	new JPanel();
		topLeft.setLayout		(new BoxLayout(topLeft, BoxLayout.Y_AXIS));
		JPanel topRight		=	new JPanel();
		topRight.setLayout		(new BoxLayout(topRight, BoxLayout.Y_AXIS));
		JPanel topBottom	=	new JPanel();
		topBottom.setLayout		(new BoxLayout(topBottom, BoxLayout.X_AXIS));
		//add top components
		topLeft.add				(nameL);
		topLeft.add				(Box.createRigidArea(new Dimension (0,19)));
		topLeft.add				(addressL);
		topLeft.add				(Box.createRigidArea(new Dimension (0,19)));
		topLeft.add				(phoneL);
		topLeft.add				(Box.createRigidArea(new Dimension (0,20)));
		panel.add				(topLeft, BorderLayout.WEST);
		topRight.add			(name);
		topRight.add			(Box.createRigidArea(new Dimension (0,10)));
		topRight.add			(address);
		topRight.add			(Box.createRigidArea(new Dimension (0,10)));
		topRight.add			(phone);
		topRight.add			(Box.createRigidArea(new Dimension (0,10)));
		panel.add				(topRight, BorderLayout.EAST);
		topBottom.add			(Box.createRigidArea(new Dimension (100,0)));
		topBottom.add			(add);
		topBottom.add			(Box.createRigidArea(new Dimension (10,0)));
		topBottom.add			(reset);
		panel.add				(topBottom, BorderLayout.SOUTH);
		panel.setBorder			(BorderFactory.createTitledBorder("Add Patient"));
		//functionality for buttons
		add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				String tName		=	name.getText();
				String tAddress		=	address.getText();
				String tPhone		=	phone.getText();
				if (controller.addPatient(tName, tAddress, tPhone))
				{
					name.setText("");
					address.setText("");
					phone.setText("");
				}
			}
		});

		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				name.setText("");
				address.setText("");
				phone.setText("");
			}
		});
	}

	private void tabOneMiddle(JPanel patMiddle) {
		//create middle components for 1st tab
		JLabel nameSearchL			= 	new JLabel("Patient Name: ");
		JLabel patientNoSearchL		= 	new JLabel("Patient No:");
		JTextField nameSearch 		= 	new JTextField(24);
		JTextField patientNoSearch	= 	new JTextField(24);
		JButton search				= 	new JButton("Submit");
		JButton searchReset			= 	new JButton("Reset");
		JPanel middleLeft 			=	new JPanel();
		middleLeft.setLayout			(new BoxLayout(middleLeft, BoxLayout.Y_AXIS));
		JPanel middleRight			=	new JPanel();
		middleRight.setLayout			(new BoxLayout(middleRight, BoxLayout.Y_AXIS));
		JPanel middleBottom			=	new JPanel();
		middleBottom.setLayout			(new BoxLayout(middleBottom, BoxLayout.X_AXIS));
		//add middle components
		middleLeft.add				(nameSearchL);
		middleLeft.add				(Box.createRigidArea(new Dimension (0,19)));
		middleLeft.add				(patientNoSearchL);
		middleLeft.add				(Box.createRigidArea(new Dimension (0,19)));
		patMiddle.add				(middleLeft, BorderLayout.WEST);
		middleRight.add				(nameSearch);
		middleRight.add				(Box.createRigidArea(new Dimension (0,10)));
		middleRight.add				(patientNoSearch);
		patMiddle.add				(middleRight, BorderLayout.EAST);
		middleBottom.add			(Box.createRigidArea(new Dimension (100,0)));
		middleBottom.add			(search);
		middleBottom.add			(Box.createRigidArea(new Dimension (10,0)));
		middleBottom.add			(searchReset);
		patMiddle.add				(middleBottom, BorderLayout.SOUTH);
		patMiddle.setBorder			(BorderFactory.createTitledBorder("Patient Search"));
		//functionality for buttons
		search.addActionListener	(new ActionListener() {
			public void actionPerformed (ActionEvent event) {
				int tempPatNo=-1;
				String tempPatName = nameSearch.getText();
				String tempPatNoString = patientNoSearch.getText();
				if (!tempPatNoString.isEmpty())
					tempPatNo = Integer.parseInt(tempPatNoString);
				if (controller.searchPatient(tempPatName, tempPatNo)!=null)			//calls searchPatient method of MyController class, returns Patient object if found
				{
					Patient myPatient = controller.searchPatient(tempPatName, tempPatNo);	//copy reference to Patient object found in above if statement 
					createPatientPopUp(myPatient);	//calls method to create popup for given patient
					nameSearch.setText("");
					patientNoSearch.setText("");
				}
				else 
					JOptionPane.showMessageDialog(null, "Record not found");
			}
		});

		searchReset.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent event) {
				nameSearch.setText("");
				patientNoSearch.setText("");
			}
		});

	}

	private void tabOneBottom(JPanel patBottom) {
		//create bottom components for 1st tab
		JLabel click			= 	new JLabel("Click here to view all patient details: ");
		JButton viewAll			=	new JButton("View All");
		JPanel bottomLeft		=	new JPanel();
		JPanel bottomRight		=	new JPanel();
		//add components
		bottomLeft.setLayout		(new BoxLayout(bottomLeft, BoxLayout.X_AXIS));
		bottomRight.setLayout		(new BoxLayout(bottomRight, BoxLayout.X_AXIS));
		bottomLeft.add				(click);
		patBottom.add				(bottomLeft, BorderLayout.WEST);
		bottomRight.add				(viewAll);
		patBottom.add				(bottomRight, BorderLayout.EAST);
		patBottom.setBorder			(BorderFactory.createTitledBorder("Patient Details"));		
		//functionality 
		viewAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				String temp = controller.viewAllPatients();		//call to viewAll method of MyController class returns a string
				if (temp!= null)
					createViewAllPopup("All Patients", temp);
			}
		});
	}

	private void createTabTwo() {
		procedureTP.setLayout		(new BoxLayout(procedureTP, BoxLayout.Y_AXIS));
		//create panels for 2nd tab
		JPanel procMain 		= 	new JPanel();
		procedureTP.add				(procMain);
		procMain.setLayout			(new BoxLayout(procMain, BoxLayout.Y_AXIS));
		
		//create inner panels
		JPanel procTop			=	new JPanel();
		procTop.setLayout			(new BorderLayout());
		procTop.setMaximumSize		(new Dimension(390,150));
		JPanel procMiddle		=	new JPanel();
		procMiddle.setLayout		(new BorderLayout());
		procMiddle.setMaximumSize	(new Dimension(390,150));
		JPanel procBottom		=	new JPanel();
		procBottom.setLayout		(new BorderLayout());
		procMain.add				(procTop);
		procMain.add				(procMiddle);
		procMain.add				(procBottom);	
		procMain.add				(new JPanel());
		
		//method calls to create contents of panels for tab two
		tabTwoTop(procTop);
		tabTwoMiddle(procMiddle);
		tabTwoBottom(procBottom);
	}

	private void tabTwoTop(JPanel procTop) {
		//create top components
		JLabel procNameL 	= 	new JLabel("Name:");
		JLabel procPriceL	= 	new JLabel("Price:");
		JTextField procName	= 	new JTextField(24);
		JTextField procPrice= 	new JTextField(24);
		JButton addProc			= 	new JButton("Submit");
		JButton procReset		= 	new JButton("Reset");
		JPanel topLeft 		=	new JPanel();
		topLeft.setLayout		(new BoxLayout(topLeft, BoxLayout.Y_AXIS));
		JPanel topRight		=	new JPanel();
		topRight.setLayout		(new BoxLayout(topRight, BoxLayout.Y_AXIS));
		JPanel topBottom	=	new JPanel();
		topBottom.setLayout		(new BoxLayout(topBottom, BoxLayout.X_AXIS));
		
		//add top components
		topLeft.add				(procNameL);
		topLeft.add				(Box.createRigidArea(new Dimension (0,19)));
		topLeft.add				(procPriceL);
		topLeft.add				(Box.createRigidArea(new Dimension (0,19)));
		procTop.add				(topLeft, BorderLayout.WEST);
		topRight.add			(procName);
		topRight.add			(Box.createRigidArea(new Dimension (0,10)));
		topRight.add			(procPrice);
		topRight.add			(Box.createRigidArea(new Dimension (0,10)));
		procTop.add				(topRight, BorderLayout.EAST);
		topBottom.add			(Box.createRigidArea(new Dimension (100,0)));
		topBottom.add			(addProc);
		topBottom.add			(Box.createRigidArea(new Dimension (10,0)));
		topBottom.add			(procReset);
		procTop.add				(topBottom, BorderLayout.SOUTH);
		procTop.setBorder		(BorderFactory.createTitledBorder("Add Procedure"));
		
		//functionality
		addProc.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e) {
				String tempProcName		 	= procName.getText();
				String tempProcCostString 	= procPrice.getText();

				if (controller.addProcedure(tempProcName, tempProcCostString))	//call to addProcedure method of MyController class, returns boolean
				{
					procName.setText("");
					procPrice.setText("");
				}
			}
		});

		procReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				procName.		setText("");
				procPrice.		setText("");
			}
		});
	}

	private void tabTwoMiddle(JPanel procMiddle) {
		//create middle components
		JLabel procSearchL			= 	new JLabel("Name: ");
		JLabel procNoSearchL		= 	new JLabel("Number: ");
		JTextField procSearch		= 	new JTextField(24);
		JTextField procNoSearch		= 	new JTextField(24);
		JButton search				= 	new JButton("Search");
		JButton procReset			= 	new JButton("Reset");
		JPanel middleLeft 			=	new JPanel();
		middleLeft.setLayout			(new BoxLayout(middleLeft, BoxLayout.Y_AXIS));
		JPanel middleRight			=	new JPanel();
		middleRight.setLayout			(new BoxLayout(middleRight, BoxLayout.Y_AXIS));
		JPanel middleBottom			=	new JPanel();
		middleBottom.setLayout			(new BoxLayout(middleBottom, BoxLayout.X_AXIS));
		
		//add middle components
		middleLeft.add				(procSearchL);
		middleLeft.add				(Box.createRigidArea(new Dimension (0,18)));
		middleLeft.add				(procNoSearchL);
		middleLeft.add				(Box.createRigidArea(new Dimension (0,18)));
		procMiddle.add				(middleLeft, BorderLayout.WEST);
		middleRight.add				(procSearch);
		middleRight.add				(Box.createRigidArea(new Dimension (0,11)));
		procMiddle.add				(middleRight, BorderLayout.EAST);
		middleRight.add				(procNoSearch);
		procMiddle.add				(middleRight, BorderLayout.EAST);
		middleBottom.add			(Box.createRigidArea(new Dimension (100,0)));
		middleBottom.add			(Box.createRigidArea(new Dimension (100,0)));
		middleBottom.add			(search);
		middleBottom.add			(Box.createRigidArea(new Dimension (10,0)));
		middleBottom.add			(procReset);
		procMiddle.add				(middleBottom, BorderLayout.SOUTH);
		procMiddle.setBorder		(BorderFactory.createTitledBorder("Procedure Search"));
		
		//functionality for buttons
		search.addActionListener	(new ActionListener() {
			public void actionPerformed (ActionEvent event) {
				String tempProcName = procSearch.getText();
				String tempProcNoString = procNoSearch.getText();
				if (controller.searchProcedure(tempProcName, tempProcNoString)!=null)	//searchProcedure method of MyController class returns Procedure object if found
				{
					Procedure myProcedure = controller.searchProcedure(tempProcName, tempProcNoString);
					createProcedurePopup(myProcedure);		//method call to create popup for Procedure object found above
					procSearch.setText("");
					procNoSearch.setText("");
				}
				else 
					JOptionPane.showMessageDialog(null, "Record not found");
			}
		});
	
		procReset.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent event) {
				procSearch.setText("");
				procNoSearch.setText("");
			}
		});

	}

	private void tabTwoBottom(JPanel procBottom) {
		//create bottom components for 1st tab
		JLabel click			= 	new JLabel("Click here to view all procedure details: ");
		JButton viewAll			=	new JButton("View All");
		JPanel bottomLeft		=	new JPanel();
		JPanel bottomRight		=	new JPanel();
		
		//add components
		bottomLeft.setLayout		(new BoxLayout(bottomLeft, BoxLayout.X_AXIS));
		bottomRight.setLayout		(new BoxLayout(bottomRight, BoxLayout.X_AXIS));
		bottomLeft.add				(click);
		procBottom.add				(bottomLeft, BorderLayout.WEST);
		bottomRight.add				(viewAll);
		procBottom.add				(bottomRight, BorderLayout.EAST);
		procBottom.setBorder		(BorderFactory.createTitledBorder("Procedure Details"));
		procBottom.setMaximumSize	(new Dimension(390,50));

		//functionality
		viewAll.addActionListener(new ActionListener()	{
			public void actionPerformed(ActionEvent e)	{
				String temp = controller.viewAllProcedures();		 //viewAllProcedures method in MyController class returns String representation of all Procedure objects
				if (temp!= null)
					createViewAllPopup("All Procedures", temp);
			}

		});
	}

	private void createTabThree() {
		//create panels for 3rd tab
		paymentTP.setLayout		(new BoxLayout(paymentTP, BoxLayout.Y_AXIS));
		JPanel payMain 		= 	new JPanel();
		paymentTP.add			(payMain);
		payMain.setLayout		(new BoxLayout(payMain, BoxLayout.Y_AXIS));

		//create inner panels
		JPanel payTop		=	new JPanel();
		JPanel payBottom	=	new JPanel();
		payMain.add				(payTop);
		payMain.add				(payBottom);

		//method call to create tab three contents
		tabThreeTop(payTop);
	}

	private void tabThreeTop(JPanel payTop) {
		//create top components
		JLabel nameL 			= 	new JLabel("Patient Name:");
		JLabel dateL			= 	new JLabel("Date:");
		JLabel dateFormatL		= 	new JLabel("(dd-mm-yyyy)");
		JLabel amountL 			= 	new JLabel("Amount:");
		JTextField name 		= 	new JTextField(23);
		JTextField date			= 	new JTextField(23);
		JTextField amount		= 	new JTextField(23);
		JButton add				= 	new JButton("Submit");
		JButton reset			= 	new JButton("Reset");
		JPanel topLeft 			=	new JPanel();
		topLeft.setLayout			(new BoxLayout(topLeft, BoxLayout.Y_AXIS));
		JPanel topRight			=	new JPanel();
		topRight.setLayout			(new BoxLayout(topRight, BoxLayout.Y_AXIS));
		JPanel topBottom		=	new JPanel();
		topBottom.setLayout			(new BoxLayout(topBottom, BoxLayout.X_AXIS));
		
		//add top components
		topLeft.add				(Box.createRigidArea(new Dimension (0,5)));
		topLeft.add				(nameL);
		topLeft.add				(Box.createRigidArea(new Dimension (0,7)));
		topLeft.add				(dateL);
		topLeft.add				(dateFormatL);
		topLeft.add				(Box.createRigidArea(new Dimension (0,8)));
		topLeft.add				(amountL);
		topLeft.add				(Box.createRigidArea(new Dimension (0,20)));
		payTop.add				(topLeft, BorderLayout.WEST);
		topRight.add			(name);
		topRight.add			(Box.createRigidArea(new Dimension (0,10)));
		topRight.add			(date);
		topRight.add			(Box.createRigidArea(new Dimension (0,10)));
		topRight.add			(amount);
		topRight.add			(Box.createRigidArea(new Dimension (0,10)));
		payTop.add				(topRight, BorderLayout.EAST);
		topBottom.add			(Box.createRigidArea(new Dimension (10,0)));
		topBottom.add			(add);
		topBottom.add			(Box.createRigidArea(new Dimension (10,0)));
		topBottom.add			(reset);
		payTop.add				(topBottom, BorderLayout.SOUTH);
		payTop.setBorder		(BorderFactory.createTitledBorder("Add Payment"));
		
		//functionality for buttons
		add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				String tName		=	name.getText();
				String tDate		=	date.getText();
				String tAmount		=	amount.getText();
				try {
					if (controller.searchAddPayment(tName, tDate, tAmount))	//this method checks if the patient requested exists and adds a payment if successful
					{
						name.setText("");
						date.setText("");
						amount.setText("");
					}
				} catch (HeadlessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				name.setText("");
				date.setText("");
				amount.setText("");
			}
		});
	}

	//this method creates a popup which is used by both the viewAllPatients and viewAllProcedure functions
	private void createViewAllPopup(String prompt, String temp) {
		//create panel
		JFrame popup 			= 	new JFrame(prompt);
		popup.setSize				(470, 510);
		JPanel main				=	new JPanel();
		main.setLayout				(new FlowLayout());
		JTextArea info			=	new JTextArea(10, 100);
		info.setLineWrap			(true);
		info.setEditable			(false);
		info.setVisible				(true);
		JScrollPane scroll		=	new JScrollPane(info);
		scroll.setPreferredSize		(new Dimension(450,490));
		//		next two lines not functioning as required, removed
		//		int horizontalPolicy 	= 	JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED;
		//		scroll.setHorizontalScrollBarPolicy(horizontalPolicy);
		main.add					(scroll);
		//insert text from controller class
		info.append(temp);
		//finalise panel
		popup.getContentPane		().add	(main); 
		popup.isAlwaysOnTop			();
		popup.setResizable			(false);
		popup.setLocationRelativeTo	(null);
		popup.setVisible			(true);
	}

	private void createPatientPopUp(Patient myPatient) {
		//first section creates panels for popup
		popupFrame 		= 	new JFrame(myPatient.getPatientName());
		popupFrame.setSize			(390,300);
		JTabbedPane ptp			= 	new JTabbedPane();
		
		//creates tabs
		JPanel 		infoTP 		= 	new JPanel();
		infoTP.setLayout			(new BoxLayout(infoTP, BoxLayout.Y_AXIS));
		JPanel 		editTP 		=  	new JPanel();
		editTP.setLayout			(new BoxLayout(editTP, BoxLayout.Y_AXIS));
		JPanel 		addProcTP	= 	new JPanel();
		addProcTP.setLayout			(new BoxLayout(addProcTP, BoxLayout.Y_AXIS));
		JPanel 		addPayTP 	= 	new JPanel();
		ptp.addTab				("Patient Info", infoTP);
		ptp.addTab				("Edit Patient", editTP);
		ptp.addTab				("Procedures", addProcTP);
		ptp.addTab				("Payments", addPayTP);

		//methods which construct tab contents
		createPatInfoPanel		(myPatient, infoTP);
		createEditPatPanel		(myPatient, editTP);
		createProcPanel			(myPatient, addProcTP);	
		createPayPanel			(myPatient, addPayTP);

		//finalise popup
		popupFrame.getContentPane			().add	(ptp); 
		popupFrame.isAlwaysOnTop			();
		popupFrame.setResizable				(false);
		popupFrame.setLocationRelativeTo	(null);
		popupFrame.setVisible				(true);
	}

	private void createPatInfoPanel(Patient myPatient, JPanel panel) {
		//create components
		JPanel top 			= 	new JPanel();
		top.setLayout			(new BorderLayout());
		JPanel buttons 		=	new JPanel();
		JTextArea info		=	new JTextArea(5, 50);
		info.setLineWrap		(false);
		info.setEditable		(false);
		info.setVisible			(true);
		JScrollPane scroll	=	new JScrollPane(info);
		scroll.setPreferredSize	(new Dimension(350,180));
		top.add					(scroll, BorderLayout.CENTER);
		
		String temp ="Pat. Number\tName\tAddress\tPhone\n======\t======\t======\t======";
			temp += (myPatient.toString() + "\n");	
			temp+=controller.amountOwed(myPatient);		//this method calls the calcIsPaid method also and returns how much is owed, reduces code
			
		info.append			(temp);
		top.setBorder		(BorderFactory.createTitledBorder("Patient Details"));
		panel.add			(top, BorderLayout.NORTH);

		JButton delete	=	new JButton("Delete Patient Record");
		buttons.add			(delete);
		panel.add			(buttons, BorderLayout.SOUTH);

		//functionality for delete button
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.deletePatient(myPatient);
				popupFrame.dispose();
			}
		});
	}

	private void createEditPatPanel(Patient myPatient, JPanel panel) {
		//create top components for 1st tab
		JLabel nameL 		= 	new JLabel("Patient Name:");
		JLabel addressL		= 	new JLabel("Address:");
		JLabel phoneL 		= 	new JLabel("Phone Number:");
		JTextField name 	= 	new JTextField(22);
		JTextField address	= 	new JTextField(22);
		JTextField phone 	= 	new JTextField(22);
		JButton update		= 	new JButton("Update");
		JButton reset		= 	new JButton("Reset");
		JPanel labels 		=	new JPanel();
		labels.setLayout		(new BoxLayout(labels, BoxLayout.Y_AXIS));
		JPanel textFields	=	new JPanel();
		textFields.setLayout	(new BoxLayout(textFields, BoxLayout.Y_AXIS));
		JPanel buttons		=	new JPanel();
		buttons.setLayout		(new BoxLayout(buttons, BoxLayout.X_AXIS));
		JPanel top			=	new JPanel();
		top.setLayout			(new BorderLayout());
		top.setMaximumSize		(new Dimension(370,120));
		
		//add top components
		labels.add				(nameL);
		labels.add				(Box.createRigidArea(new Dimension (0,19)));
		labels.add				(addressL);
		labels.add				(Box.createRigidArea(new Dimension (0,19)));
		labels.add				(phoneL);
		labels.add				(Box.createRigidArea(new Dimension (0,20)));
		top.add					(labels, BorderLayout.WEST);
		textFields.add			(name);
		textFields.add			(Box.createRigidArea(new Dimension (0,10)));
		textFields.add			(address);
		textFields.add			(Box.createRigidArea(new Dimension (0,10)));
		textFields.add			(phone);
		textFields.add			(Box.createRigidArea(new Dimension (0,10)));
		top.add					(textFields, BorderLayout.EAST);
		buttons.add				(Box.createRigidArea(new Dimension (100,0)));
		buttons.add				(update);
		buttons.add				(Box.createRigidArea(new Dimension (10,0)));
		buttons.add				(reset);
		top.add					(buttons, BorderLayout.SOUTH);
		panel.setBorder			(BorderFactory.createTitledBorder("Edit Patient"));
		panel.add				(top, BorderLayout.NORTH);
		
		//functionality for buttons
		update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				String tName		=	name.getText();
				String tAddress		=	address.getText();
				String tPhone		=	phone.getText();
				if (controller.updatePatient(myPatient, tName, tAddress, tPhone))	//this method passes variables to relevant setters of Patient object
				{
					popupFrame.dispose();
					createPatientPopUp(myPatient);
				}
			}
		});

		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				name.setText("");
				address.setText("");
				phone.setText("");
			}
		});
	}

	private void createProcPanel(Patient myPatient, JPanel panel) {
		//set colour of dropdown menus
		UIManager.put("ComboBox.background", new ColorUIResource(UIManager.getColor("TextField.background")));
		UIManager.put("ComboBox.foreground", new ColorUIResource(UIManager.getColor("TextField.foreground")));
		UIManager.put("ComboBox.selectionBackground", new ColorUIResource(Color.LIGHT_GRAY));
		UIManager.put("ComboBox.selectionForeground", new ColorUIResource(Color.WHITE));
		
		//create panels
		JPanel top 			= 	new JPanel();
		top.setLayout			(new BorderLayout());
		JPanel middle		=	new JPanel();
		middle.setLayout		(new BorderLayout());
		JPanel bottom 		=	new JPanel();
		bottom.setLayout		(new BoxLayout(bottom, BoxLayout.X_AXIS));

		//add procedure section
		String tempAdd 				= controller.getProcedureNames();		//this method returns all Procedure names in a String with ';' as the delimiter
		String[] choices = tempAdd.split(";");								//split the String into an array
		final JComboBox<String> addCb 	= new JComboBox<String>(choices);	//pass the array into a drop box
		JLabel addProcL				= new JLabel("Select a procedure.");
		JButton add					= new JButton("Add");
		
		//add components
		top.add(addProcL, BorderLayout.WEST);
		top.add(addCb, BorderLayout.CENTER);
		top.add(add, BorderLayout.EAST);
		
		//add functionality for drop box/add button
		add.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			int index =addCb.getSelectedIndex();
			if (controller.addPatientProc(myPatient, index))	//adds a procedure to a patients own procedure list
			{
				popupFrame.dispose();
				createPatientPopUp(myPatient);
			}
		}
	});
	
		// remove procedure section
		String tempRemove					= controller.getPatientProcedureNames(myPatient);	//returns String containing all of a patients own procedures delimited by ';'
		String[] removeChoices 				= tempRemove.split(";");							//splits String into an array
		final JComboBox<String> removeCb 	= new JComboBox<String>(removeChoices);				//pass array into comboBox
		removeCb.setPreferredSize			(new Dimension(3,20));
		JLabel removeProcL					= new JLabel("Remove a procedure.");
		JButton remove						= new JButton("Remove");
		
		//add components
		middle.add(removeProcL, BorderLayout.WEST);
		middle.add(removeCb, BorderLayout.CENTER);
		middle.add(remove, BorderLayout.EAST);
		
		//functionality for comboBox/remove button
		remove.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			int index = removeCb.getSelectedIndex();
			if (controller.removePatientProc(myPatient, index))		//removes selected procedure from patients own collection
			{
				popupFrame.dispose();
				createPatientPopUp(myPatient);
			}
		}
	});
	
		//finalise the panel
		top.setBorder			(BorderFactory.createTitledBorder("Add Procedure"));
		top.setMaximumSize		(new Dimension(370, 50));
		middle.setBorder		(BorderFactory.createTitledBorder("Remove Procedure"));
		middle.setMaximumSize	(new Dimension(370, 50));
		panel.add				(top);
		panel.add				(middle);
		panel.add				(bottom);
		

		
	}
	
	private void createPayPanel(Patient myPatient, JPanel panel) {
		//create top components for 1st tab
		JLabel dateL 		= 	new JLabel("Date:");
		JLabel dateFormatL	=	new JLabel("(dd-mm-yyyy)");
		JLabel amountL		= 	new JLabel("Amount:");
		JTextField date 	= 	new JTextField(22);
		JTextField amount	= 	new JTextField(22);
		JButton add			= 	new JButton("Add");
		JButton reset		= 	new JButton("Reset");
		JPanel labels 		=	new JPanel();
		labels.setLayout		(new BoxLayout(labels, BoxLayout.Y_AXIS));
		JPanel textFields	=	new JPanel();
		textFields.setLayout	(new BoxLayout(textFields, BoxLayout.Y_AXIS));
		JPanel buttons		=	new JPanel();
		buttons.setLayout		(new BoxLayout(buttons, BoxLayout.X_AXIS));
		JPanel top			=	new JPanel();
		top.setLayout			(new BorderLayout());
		top.setMaximumSize		(new Dimension(370,120));
		
		//add top components
		labels.add				(dateL);
		labels.add				(dateFormatL);
		labels.add				(Box.createRigidArea(new Dimension (0,19)));
		labels.add				(amountL);
		labels.add				(Box.createRigidArea(new Dimension (0,19)));
		top.add					(labels, BorderLayout.WEST);
		textFields.add			(date);
		textFields.add			(Box.createRigidArea(new Dimension (0,10)));
		textFields.add			(amount);
		textFields.add			(Box.createRigidArea(new Dimension (0,10)));
		top.add					(textFields, BorderLayout.EAST);
		buttons.add				(Box.createRigidArea(new Dimension (100,0)));
		buttons.add				(add);
		buttons.add				(Box.createRigidArea(new Dimension (10,0)));
		buttons.add				(reset);
		top.add					(buttons, BorderLayout.SOUTH);
		panel.setBorder			(BorderFactory.createTitledBorder("Add Payment"));
		panel.add				(top, BorderLayout.NORTH);
		
		//functionality for buttons
		add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				String tDate		=	date.getText();
				String tamount		=	amount.getText();
				try {
					if (controller.addPatientPayment(myPatient, tDate, tamount))	//method which adds a payment to a patients collection
					{
						popupFrame.dispose();
						createPatientPopUp(myPatient);
					}
				} catch (HeadlessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				date.setText("");
				amount.setText("");
			}
		});
	}

	private void createProcedurePopup(Procedure myProcedure) {
		//first section creates panels for popup
		procPopupFrame 			= 	new JFrame(myProcedure.getProcName());
		procPopupFrame.setSize			(370,300);
		JTabbedPane ptp			= 	new JTabbedPane();
		//creates tabs
		JPanel 		infoTP 		= 	new JPanel();
		infoTP.setLayout			(new BoxLayout(infoTP, BoxLayout.Y_AXIS));
		JPanel 		editTP 		=  	new JPanel();
		editTP.setLayout			(new BoxLayout(editTP, BoxLayout.Y_AXIS));
		ptp.addTab					("Procedure Info", infoTP);
		ptp.addTab					("Edit Procedure", editTP);

		//methods which construct tab contents
		createProcInfoPanel			(myProcedure, infoTP);
		createEditProcPanel			(myProcedure, editTP);		

		//finalise popup
		procPopupFrame.getContentPane			().add	(ptp); 
		procPopupFrame.isAlwaysOnTop			();
		procPopupFrame.setResizable				(false);
		procPopupFrame.setLocationRelativeTo	(null);
		procPopupFrame.setVisible				(true);
	}

	private void createProcInfoPanel (Procedure myProcedure, JPanel panel) {
		//create components
		JPanel top 		= 	new JPanel();
		top.setLayout		(new BorderLayout());
		JPanel buttons 	=	new JPanel();
		JTextArea info	=	new JTextArea(5, 50);
		info.setLineWrap	(false);
		info.setEditable	(false);
		info.setVisible		(true);
		JScrollPane scroll	=	new JScrollPane(info);
		scroll.setPreferredSize	(new Dimension(350,180));
		top.add				(scroll, BorderLayout.CENTER);
		info.setText		("Proc. Number\tName\tCost\n======\t======\t======" + myProcedure.toString());
		top.setBorder		(BorderFactory.createTitledBorder("Patient Details"));
		panel.add			(top, BorderLayout.NORTH);
		
		JButton delete	=	new JButton("Delete Procedure Record");
		buttons.add			(delete);
		panel.add			(buttons, BorderLayout.SOUTH);

		//functionality for delete button
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(controller.deleteProcedure(myProcedure))	//deletes the selected procedure
					procPopupFrame.dispose();
			}
		});
	}

	private void createEditProcPanel (Procedure myProcedure, JPanel panel) {
		//create top components for 1st tab
		JLabel nameL 		= 	new JLabel("Procedure Name:");
		JLabel costL		= 	new JLabel("Cost:");
		JTextField name 	= 	new JTextField(22);
		JTextField cost		= 	new JTextField(22);
		JButton update		= 	new JButton("Update");
		JButton reset		= 	new JButton("Reset");
		JPanel labels 		=	new JPanel();
		labels.setLayout		(new BoxLayout(labels, BoxLayout.Y_AXIS));
		JPanel textFields	=	new JPanel();
		textFields.setLayout	(new BoxLayout(textFields, BoxLayout.Y_AXIS));
		JPanel buttons		=	new JPanel();
		buttons.setLayout		(new BoxLayout(buttons, BoxLayout.X_AXIS));
		JPanel top			=	new JPanel();
		top.setLayout			(new BorderLayout());
		top.setMaximumSize		(new Dimension(370,120));
		
		//add top components
		labels.add				(nameL);
		labels.add				(Box.createRigidArea(new Dimension (0,19)));
		labels.add				(costL);
		labels.add				(Box.createRigidArea(new Dimension (0,19)));
		top.add					(labels, BorderLayout.WEST);
		textFields.add			(name);
		textFields.add			(Box.createRigidArea(new Dimension (0,10)));
		textFields.add			(cost);
		textFields.add			(Box.createRigidArea(new Dimension (0,10)));
		top.add					(textFields, BorderLayout.EAST);
		buttons.add				(Box.createRigidArea(new Dimension (100,0)));
		buttons.add				(update);
		buttons.add				(Box.createRigidArea(new Dimension (10,0)));
		buttons.add				(reset);
		top.add					(buttons, BorderLayout.SOUTH);
		panel.setBorder			(BorderFactory.createTitledBorder("Edit Procedure"));
		panel.add				(top, BorderLayout.NORTH);
		
		//functionality for buttons
		update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				String tName		=	name.getText();
				String tCostString	=	cost.getText();
				if (controller.updateProcedure(myProcedure, tName, tCostString)) //passes date into relevant setters of Procedure object 
				{
					procPopupFrame.dispose();
					createProcedurePopup(myProcedure);
				}
			}
		});

		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				name.setText("");
				cost.setText("");
			}
		});
	}
}